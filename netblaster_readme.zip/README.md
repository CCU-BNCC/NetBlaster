# NetBlaster

## English Version

NetBlaster is a powerful and user-friendly combined HTTP & HTTPS DDoS testing tool developed by MD Abdullah. This tool is designed to help security professionals and enthusiasts test the resilience and health of web servers by simulating real-world attack traffic. It features multi-threading, live status updates, IP health check, port scanning, and detailed logging of successes and failures.

### Features:
- Supports TCP Flood (HTTP) and HTTPS Flood attacks
- Multi-threaded for maximum efficiency and speed
- Real-time status display of successful and failed packets
- Live health check of target IP (ping test)
- Port scanning to detect open ports on the target
- Up/down status check of target website
- Config save/load feature for convenience
- Logs success and failure attempts in separate files
- User-friendly input validation and error handling

### Usage:
```bash
python3 netblaster.py
```
Follow on-screen prompts to configure the attack parameters and start the test.

### Disclaimer:
This tool is intended for authorized security testing only. Unauthorized use against systems without permission is illegal and unethical. Use responsibly.

### Author:
MD Abdullah

---

## বাংলা সংস্করণ

NetBlaster একটি শক্তিশালী এবং ব্যবহারকারী বান্ধব HTTP ও HTTPS DDoS টেস্টিং টুল, যা MD Abdullah কর্তৃক তৈরি। এটি নিরাপত্তা বিশেষজ্ঞ এবং আগ্রহীদের জন্য ওয়েব সার্ভারের প্রতিরোধ ক্ষমতা পরীক্ষা করার জন্য ডিজাইন করা হয়েছে, যেখানে বাস্তব দুনিয়ার আক্রমণ সিমুলেট করা হয়। এর মধ্যে রয়েছে মাল্টি-থ্রেডিং, লাইভ স্ট্যাটাস, আইপি হেলথ চেক, পোর্ট স্ক্যানিং এবং সফল ও ব্যর্থ প্রচেষ্টার বিস্তারিত লগিং সুবিধা।

### বৈশিষ্ট্যসমূহ:
- TCP Flood (HTTP) ও HTTPS Flood সাপোর্ট
- সর্বোচ্চ দক্ষতা ও গতি নিশ্চিত মাল্টি-থ্রেডেড
- সফল ও ব্যর্থ প্যাকেটের লাইভ স্ট্যাটাস
- টার্গেট আইপির লাইভ হেলথ চেক (পিং টেস্ট)
- টার্গেট সার্ভারে খোলা পোর্ট সনাক্তকরণ
- ওয়েবসাইট আপ/ডাউন স্ট্যাটাস যাচাই
- কনফিগারেশন সংরক্ষণ ও লোড সুবিধা
- সফল ও ব্যর্থ প্রচেষ্টার আলাদা লগ ফাইল
- ব্যবহারকারী বান্ধব ইনপুট ভ্যালিডেশন ও এরর হ্যান্ডলিং

### ব্যবহার পদ্ধতি:
```bash
python3 netblaster.py
```
স্ক্রিনে প্রদত্ত নির্দেশনা অনুসরণ করে টেস্টের প্যারামিটার সেট করে শুরু করুন।

### দায়বদ্ধতা:
এই টুল শুধুমাত্র অনুমোদিত নিরাপত্তা পরীক্ষার জন্য ব্যবহৃত হবে। অনুমতি ছাড়া ব্যবহারের আইনগত ও নৈতিক পরিণতি থাকতে পারে। দায়িত্বশীল ব্যবহার নিশ্চিত করুন।

### লেখক:
MD Abdullah